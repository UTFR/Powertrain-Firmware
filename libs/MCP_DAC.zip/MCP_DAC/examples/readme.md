

Note that some examples are ESP32 specific as they use e.g. VSPI() 

|  example               |  UNO  | ESP32 |
|:-----------------------|:-----:|:-----:|
| MCP4911_test           |   Y   |   Y   |
| MCP4921_standalone     |   Y   |   Y   |
| MCP4921_test           |   Y   |   Y   |
| MCP4921_VSPI           |   N   |   Y   |
| MCP4921_wave_generator |   N   |   Y   |

